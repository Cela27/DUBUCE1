import json
import os
import matplotlib.pyplot as plt
import numpy as np

SAVE_FOLDER="C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\ZAD4_PARAMS\\LSTM"

vocab_sizes = [1000, 5000, 10000]
batch_sizes = [5, 32, 64]
freezes = [True, False]
grad_clipings = [0.1, 0.5, 1]

print("Zas sve provjere koristeni su defaultni parameti(napisani ispod), osim ako je prikazano drugacije")
print("Za sve provjere koristeni su parametri: param_iter=5, param_delta=1e-4, batch_size=10, vocab_size=-1, "
      "frezee=False, grad_cliping=0.5")
print("Za sve provjere koristeni su hiperparametri: hidden_size=150, num_layers=2, dropout=0.25, bidirectional=True")

plt.figure(figsize=(100,15))
plt.tight_layout()
br_graf=1
plt.subplots_adjust(hspace=0.5)  # Adjust vertical spacing

results=[]
for vocab_size in vocab_sizes:

    results_path = os.path.join(SAVE_FOLDER, 'vocab_size_'+str(vocab_size)+'.json')

    with open(results_path) as file:
        results.extend(json.load(file))

accs = []
f1= []

for i in range(len(results)):
    if i%2==0:
        accs.append(results[i])
    else:
        f1.append(results[i])

X=np.array([0.5,1, 1.5])
plt.subplot(2, 2, br_graf)
plt.bar(X-0.05, accs, color ='c', width=0.1, edgecolor='k', label='acc')
plt.bar(X+0.05, f1, color ='m', width=0.1, edgecolor='k', label='f1')
plt.xticks(X, vocab_sizes)
plt.title("Rezultati za vocab_sizes ")
br_graf+=1

results=[]

for batch_size in batch_sizes:

    results_path = os.path.join(SAVE_FOLDER, 'batch_size_'+str(batch_size)+'.json')

    with open(results_path) as file:
        results.extend(json.load(file))

accs = []
f1= []

for i in range(len(results)):
    if i%2==0:
        accs.append(results[i])
    else:
        f1.append(results[i])

X=np.array([0.5,1, 1.5])
plt.subplot(2, 2, br_graf)
plt.bar(X-0.05, accs, color ='c', width=0.1, edgecolor='k', label='acc')
plt.bar(X+0.05, f1, color ='m', width=0.1, edgecolor='k', label='f1')
plt.xticks(X, batch_sizes)
plt.title("Rezultati za batch_sizes ")
br_graf+=1

results=[]
for freeze in freezes:

    results_path = os.path.join(SAVE_FOLDER, 'freeze_'+str(freeze)+'.json')

    with open(results_path) as file:
        results.extend(json.load(file))

accs = []
f1= []

for i in range(len(results)):
    if i%2==0:
        accs.append(results[i])
    else:
        f1.append(results[i])

X=np.array([0.5,1])
plt.subplot(2, 2, br_graf)
plt.bar(X-0.05, accs, color ='c', width=0.1, edgecolor='k', label='acc')
plt.bar(X+0.05, f1, color ='m', width=0.1, edgecolor='k', label='f1')
plt.xticks(X, freezes)
plt.title("Rezultati za freezes ")
br_graf+=1
plt.legend()
results=[]

i=1
for grad_cliping in grad_clipings:

    results_path = os.path.join(SAVE_FOLDER, 'grad_cliping_'+str(i) + '.json')
    i+=1
    with open(results_path) as file:
        results.extend(json.load(file))

accs = []
f1= []

for i in range(len(results)):
    if i%2==0:
        accs.append(results[i])
    else:
        f1.append(results[i])

X=np.array([0.5,1, 1.5])
plt.subplot(2, 2, br_graf)
plt.bar(X-0.05, accs, color ='c', width=0.1, edgecolor='k', label='acc')
plt.bar(X+0.05, f1, color ='m', width=0.1, edgecolor='k', label='f1')
plt.xticks(X, grad_clipings)
plt.title("Rezultati za grad_clipings ")
br_graf+=1

plt.show()