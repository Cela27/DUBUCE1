import pickle

from matplotlib import image as mpimg

import zadatak4
from pathlib import Path
import torch
import numpy as np
import json
import matplotlib.pyplot as plt
import os

PATH = Path(__file__).parent / "out_zad4"
DATA_DIR = Path(__file__).parent / "datasets" / "CIFAR"
MODEL_PATH = Path(__file__).parent / "out_zad4" / "cifar_model.pth"
TRAIN_LOSSES_PATH = Path(__file__).parent / "out_zad4" / "train_losses.json"
VAL_LOSSES_PATH = Path(__file__).parent / "out_zad4" / "val_losses.json"
TRAIN_ACCS_PATH = Path(__file__).parent / "out_zad4" / "train_accs.json"
VAL_ACCS_PATH = Path(__file__).parent / "out_zad4" / "validate_accs.json"
LEARNING_RATES = Path(__file__).parent / "out_zad4" / "learning_rates.json"

def shuffle_data(data_x, data_y):
    indices = np.arange(data_x.shape[0])
    np.random.shuffle(indices)
    shuffled_data_x = np.ascontiguousarray(data_x[indices])
    shuffled_data_y = np.ascontiguousarray(data_y[indices])
    return shuffled_data_x, shuffled_data_y


def unpickle(file):
    fo = open(file, 'rb')
    dict = pickle.load(fo, encoding='latin1')
    fo.close()
    return dict


def load_data():
    img_height = 32
    img_width = 32
    num_channels = 3
    num_classes = 10

    train_x = np.ndarray((0, img_height * img_width * num_channels), dtype=np.float32)
    train_y = []
    for i in range(1, 6):
        subset = unpickle(os.path.join(DATA_DIR, 'data_batch_%d' % i))
        train_x = np.vstack((train_x, subset['data']))
        train_y += subset['labels']
    train_x = train_x.reshape((-1, num_channels, img_height, img_width)).transpose(0, 2, 3, 1)
    train_y = np.array(train_y, dtype=np.int32)

    subset = unpickle(os.path.join(DATA_DIR, 'test_batch'))
    test_x = subset['data'].reshape((-1, num_channels, img_height, img_width)).transpose(0, 2, 3, 1).astype(np.float32)
    test_y = np.array(subset['labels'], dtype=np.int32)

    valid_size = 5000
    train_x, train_y = shuffle_data(train_x, train_y)
    valid_x = train_x[:valid_size, ...]
    valid_y = train_y[:valid_size, ...]
    train_x = train_x[valid_size:, ...]
    train_y = train_y[valid_size:, ...]
    data_mean = train_x.mean((0, 1, 2))
    data_std = train_x.std((0, 1, 2))

    train_x = (train_x - data_mean) / data_std
    valid_x = (valid_x - data_mean) / data_std
    test_x = (test_x - data_mean) / data_std

    train_x = train_x.transpose(0, 3, 1, 2)
    valid_x = valid_x.transpose(0, 3, 1, 2)
    test_x = test_x.transpose(0, 3, 1, 2)

    train_y, valid_y, test_y = (convert_to_one_hot_cifar(y) for y in (train_y, valid_y, test_y))


    return train_x, valid_x, test_x, train_y, valid_y, test_y, data_mean, data_std


def convert_to_one_hot_cifar(data):
    converted = list()

    for example in data:
        primjer = np.zeros(10)
        primjer[example.data] = 1.

        converted.append(primjer)
    converted = np.asarray(converted)
    return converted

train_x, valid_x, test_x, train_y, valid_y, test_y, data_mean, data_std = load_data()

train_x = train_x.astype('float32')
valid_x = valid_x.astype('float32')
test_x = test_x.astype('float32')

train_x = torch.tensor(train_x)
valid_x = torch.tensor(valid_x)
test_x = torch.tensor(test_x)

train_y = train_y.astype('float32')
valid_y = valid_y.astype('float32')
test_y = test_y.astype('float32')

train_y = torch.tensor(train_y)
valid_y = torch.tensor(valid_y)
test_y = torch.tensor(test_y)

net=zadatak4.ConvolutionalModelCifar(10)
accuracy, precision, recall, f1, test_loss=net.evaluate(test_x, test_y)
print("Rezultat za test skup-Točnost:" + str(accuracy))
print()

#zadatak4.analyze(net, test_x, test_y, data_mean, data_std, 20, 3)

with open(TRAIN_LOSSES_PATH) as json_file:
    train_losses = json.load(json_file)

with open(VAL_LOSSES_PATH) as json_file:
    validate_losses = json.load(json_file)

with open(TRAIN_ACCS_PATH) as json_file:
    train_accs = json.load(json_file)

with open(VAL_ACCS_PATH) as json_file:
    val_accs = json.load(json_file)

with open(LEARNING_RATES) as json_file:
    learning_rates = json.load(json_file)


plt.figure(figsize=(16, 8))
plt.subplot(2, 2, 1)
plt.plot(range(1, len(train_losses)+1), train_losses, label='Gubitak na train skupu kroz epohe')
plt.plot(range(1, len(validate_losses) + 1),validate_losses, label='Gubitak na train skupu kroz epohe')
plt.legend()

plt.subplot(2, 2, 2)
plt.plot(range(1, len(train_accs)+1), train_accs, label='Točnost na train skupu kroz epohe')
plt.plot(range(1, len(val_accs) + 1),[val_acc*100 for val_acc in val_accs], label='Točnost na validate skupu kroz epohe')
plt.legend()

plt.subplot(2, 2, 3)
plt.plot(range(1, len(learning_rates) + 1),learning_rates, label='Stope učenja kroz epohe')
plt.legend()
plt.show()

epoch_1=os.path.join(PATH, 'epoch_01_step_000000.png')
epoch_20=os.path.join(PATH, 'epoch_20_step_040000.png')

plt.figure(figsize=(18,12))
plt.subplot(2, 1, 1)
img = mpimg.imread(epoch_1)
plt.imshow(img)
plt.title("Epoha 1")

plt.subplot(2, 1, 2)
img = mpimg.imread(epoch_20)
plt.imshow(img)
plt.title("Epoha 20")
plt.show()