import torch
from torch import nn
import numpy as np
from pathlib import Path
import json

import os
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import accuracy_score

from torchvision.datasets import MNIST
import skimage as ski

import warnings
import math
warnings.filterwarnings("ignore")

DATA_DIR = Path(__file__).parent / "datasets" / "MNIST"
SAVE_DIR = Path(__file__).parent / "out_zad3"
MODEL_PATH = Path(__file__).parent / "out_zad3" / "conv_model.pth"


class ConvolutionalModel(nn.Module):
    def __init__(self, in_channels, conv1_width, fc1_width, class_count):

        super().__init__()

        # 28*28
        self.conv1 = nn.Conv2d(in_channels=in_channels, out_channels=conv1_width, kernel_size=5, stride=1,
                               padding='same', bias=True)
        # ostatak konvolucijskih slojeva i slojeva sažimanja
        # 28*28
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)
        # 14*14
        self.conv2 = nn.Conv2d(in_channels=16, out_channels=32, kernel_size=5, stride=1, padding='same', bias=True)
        # 14*14
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2)
        # 7*7
        # potpuno povezani slojevi
        self.fc1 = nn.Linear(32 * 7 * 7, fc1_width, bias=True)
        self.fc_logits = nn.Linear(fc1_width, class_count, bias=True)

        # parametri su već inicijalizirani pozivima Conv2d i Linear
        # ali možemo ih drugačije inicijalizirati
        self.reset_parameters()

    def reset_parameters(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
                nn.init.constant_(m.bias, 0)

            elif isinstance(m, nn.Linear) and m is not self.fc_logits:
                nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
                nn.init.constant_(m.bias, 0)

        self.fc_logits.reset_parameters()

    def forward(self, x):
        # x mora biti tensor

        h = self.conv1(x)
        h = self.pool1(h)
        h = torch.relu(h)  # može i h.relu() ili nn.functional.relu(h)

        h = self.conv2(h)
        h = self.pool2(h)
        h = torch.relu(h)

        # flatten?
        h = h.view(h.shape[0], -1)

        h = self.fc1(h)
        h = torch.relu(h)

        logits = self.fc_logits(h)
        return logits

    def crossEntropyLoss(self, x, y):
        log_sum = torch.log(torch.sum(torch.exp(x), dim=1))
        umn_sum = torch.sum(x * y, dim=1)
        L = torch.mean(log_sum - umn_sum)
        return L


def convert_to_one_hot_minst(data):
    converted = list()

    for example in data:
        primjer = np.zeros(10)
        primjer[example.data] = 1.

        converted.append(primjer)
    converted = np.asarray(converted)
    return converted


def load_data():
    ds_train, ds_test = MNIST(DATA_DIR, train=True, download=True), MNIST(DATA_DIR, train=False)
    train_x = ds_train.data.reshape([-1, 1, 28, 28]).numpy().astype(np.float) / 255
    train_y = ds_train.targets.numpy()
    train_x, valid_x = train_x[:55000], train_x[55000:]
    train_y, valid_y = train_y[:55000], train_y[55000:]
    test_x = ds_test.data.reshape([-1, 1, 28, 28]).numpy().astype(np.float) / 255
    test_y = ds_test.targets.numpy()
    train_mean = train_x.mean()
    train_x, valid_x, test_x = (x - train_mean for x in (train_x, valid_x, test_x))
    train_y, valid_y, test_y = (convert_to_one_hot_minst(y) for y in (train_y, valid_y, test_y))
    return train_x, valid_x, test_x, train_y, valid_y, test_y


def draw_conv_filters(epoch, step, weights, save_dir):
    w = weights.copy()
    num_filters = w.shape[0]
    num_channels = w.shape[1]
    k = w.shape[2]
    assert w.shape[3] == w.shape[2]
    w = w.transpose(2, 3, 1, 0)
    w -= w.min()
    w /= w.max()
    border = 1
    cols = 8
    rows = math.ceil(num_filters / cols)
    width = cols * k + (cols - 1) * border
    height = rows * k + (rows - 1) * border
    img = np.zeros([height, width, num_channels])
    for i in range(num_filters):
        r = int(i / cols) * (k + border)
        c = int(i % cols) * (k + border)
        img[r:r + k, c:c + k, :] = w[:, :, :, i]
    filename = 'conv1_epoch_%02d_step_%06d.png' % (epoch, step)
    ski.io.imsave(os.path.join(save_dir, filename), img)


def train(train_x, train_y, valid_x, valid_y, net, param_niter, param_delta, param_lambda, min_batch):
    assert train_x.shape[0] % min_batch == 0

    # *ih skuplja u touple
    optimizer = torch.optim.SGD([
        {"params": [*net.conv1.parameters(),
                    *net.conv2.parameters(),
                    *net.fc1.parameters()], "weight_decay": param_lambda},
        {"params": net.fc_logits.parameters(), "weight_decay": 0}
    ], lr=param_delta)

    scheduler = torch.optim.lr_scheduler.StepLR(optimizer=optimizer, step_size=2, gamma=0.1)
    losses = []
    val_losses = []
    for epoch in range(1, param_niter + 1):
        permutation = torch.randperm(len(train_x))
        x = torch.tensor(train_x).detach()[permutation]
        y = torch.tensor(train_y).detach()[permutation]

        x_batches = torch.split(x, min_batch)
        y_batches = torch.split(y, min_batch)

        cnt_correct = 0
        num_examples = train_x.shape[0]
        losses_batch = []
        for i, (x, y) in enumerate(zip(x_batches, y_batches)):

            # forward + backward + optimize
            outputs = net.forward(x)

            loss = net.crossEntropyLoss(outputs, y)
            loss.backward()
            losses_batch.append(loss.detach().numpy())
            optimizer.step()
            scheduler.step(epoch=epoch)

            yp = torch.argmax(outputs, 1)
            yt = torch.argmax(y, 1)
            cnt_correct += (yp == yt).sum()

            if i % 5 == 0:
                print("epoch %d, step %d/%d, batch loss = %.2f" % (epoch, i * min_batch, num_examples, loss))

            if i % 100 == 0:
                draw_conv_filters(epoch, i * min_batch, net.conv1.weight.detach().numpy(), SAVE_DIR)

            if i > 0 and i % 50 == 0:
                print("Train accuracy = %.2f" % (cnt_correct / ((i + 1) * min_batch) * 100))

            optimizer.zero_grad()

        losses.append(float(np.mean(losses_batch)))
        print("Train accuracy = %.2f" % (cnt_correct / num_examples * 100))
        val_losses.append(float(net.crossEntropyLoss(net.forward(x).clone().detach(), y)))
        evaluate(net, valid_x, valid_y)

        with open(SAVE_DIR / "train_losses.json", mode="w+") as file:
            json.dump(losses, file, sort_keys=False, ensure_ascii=False, indent=2)

        with open(SAVE_DIR / "validate_losses.json", mode="w+") as file:
            json.dump(val_losses, file, sort_keys=False, ensure_ascii=False, indent=2)


def eval(net, x):
    inputs = torch.tensor(x)
    outputs = net.forward(inputs).detach().cpu().numpy()
    return outputs


def evaluate(net, x, y):
    pred = eval(net, x)
    y_true = torch.argmax(y, axis=1)
    pred = np.argmax(pred, axis=1)
    precision = precision_score(y_true, pred, average='macro')
    recall = recall_score(y_true, pred, average='macro')
    accuracy = accuracy_score(y_true, pred)
    f1 = (2 * precision * recall) / (precision + recall)

    print("\nTočnost:" + str(accuracy) + "\n\nPreciznost:" + str(precision)
          + "\n\nOdziv:" + str(recall) + "\n\nf1:" + str(f1))
    print()


def treniraj_sve():
    train_x, valid_x, test_x, train_y, valid_y, test_y = load_data()

    net = ConvolutionalModel(in_channels=1, conv1_width=16, fc1_width=512, class_count=10)

    train_x = train_x.astype('float32')
    valid_x = valid_x.astype('float32')
    test_x = test_x.astype('float32')

    train_x = torch.tensor(train_x)
    valid_x = torch.tensor(valid_x)
    test_x = torch.tensor(test_x)

    train_y = train_y.astype('float32')
    valid_y = valid_y.astype('float32')
    test_y = test_y.astype('float32')

    train_y = torch.tensor(train_y)
    valid_y = torch.tensor(valid_y)
    test_y = torch.tensor(test_y)

    # fali spremanje modela prije finalnog runnanja
    train(train_x, train_y, valid_x, valid_y, net, param_niter=15, param_delta=1e-1,
          param_lambda=0.01, min_batch=500)
    torch.save(net.state_dict(), MODEL_PATH)


#treniraj_sve()