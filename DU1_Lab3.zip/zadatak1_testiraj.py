import torch

import utils
import zadatak1_load_data as load_data

TRAIN_PATH="C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\DATA\\sst_train.csv"
VALIDATE_PATH="C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\DATA\\sst_valid.csv"
TEST_PATH="C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\DATA\\sst_test.csv"
EMBEDDINGS_PATH="C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\DATA\\sst_glove.txt"

frekvencije = utils.frekvencije(TRAIN_PATH)
data_vocab = load_data.Vocab(frekvencije=frekvencije,max_size=-1,min_freq=1, additional=True)


label_vocab = load_data.Vocab(frekvencije={"positive": 2, "negative": 1},max_size=-1,min_freq=1)

for key, value in list(data_vocab.itos.items())[:5]:
    print(f"{key} -> {value}")

print()

for key, value in list(data_vocab.stoi.items())[:5]:
    print(f"{key}\t-> {value}")

print()
for key, value in list(label_vocab.itos.items()):
    print(f"{key} -> {value}")

print()

for key, value in list(label_vocab.stoi.items()):
    print(f"{key} -> {value}")

print("\nEmb matrica je velicine:")
emb=utils.get_embedding_matrix(vocab=data_vocab,path=EMBEDDINGS_PATH)
print(emb.shape[0], emb.shape[1])


train= load_data.NLPDataset(TRAIN_PATH,data_vocab,label_vocab)
valid= load_data.NLPDataset(VALIDATE_PATH,data_vocab,label_vocab)
test= load_data.NLPDataset(TEST_PATH,data_vocab,label_vocab)


train_data, train_label = train.instances[3]
train_id_data, train_id_label = train[3]
print()
print(f"Podatci: {train_data}")
print(f"Oznaka: {train_label}")
print(f"Identifikatorski podatci: {train_id_data}")
print(f"Identifikatorska oznaka: {train_id_label}")


dataloader = torch.utils.data.DataLoader(dataset=train,batch_size=2,shuffle=False,collate_fn=utils.pad_collate)

texts, labels, lengths = next(iter(dataloader))
print(f"Podatci:\n{texts}\n")
print(f"Oznake:\n{labels}\n")
print(f"Duljine: \n{lengths}\n")

print(train[3])