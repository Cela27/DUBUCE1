import json
import os
import matplotlib.pyplot as plt
import numpy as np

SAVE_FOLDER="C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\ZAD4_PARAMS"

rnns = ['rnn', 'lstm', 'gru']
hidden_sizes = [50, 500, 750]
bidirectionals = [True, False]
num_layer = [1, 2, 5]
dropouts = [0., 0.25, 0.5]

print("Zas sve provjere koristeni su defaultni parameti(napisani ispod), osim ako je prikazano drugacije")
print("Za sve provjere koristeni su parametri: param_iter=5, param_delta=1e-4, batch_size=10, grad_clipings=0.25")
print("Za sve provjere koristeni su hiperparametri: hidden_size=150, num_layers=2, dropout=0, bidirectional=False")

results=dict()
results['rnn']=[]
results['lstm']=[]
results['gru']=[]

plt.figure(figsize=(100,15))
plt.tight_layout()
br_graf=1
plt.subplots_adjust(hspace=0.5)  # Adjust vertical spacing

for hidden_size in hidden_sizes:

    results_path = os.path.join(SAVE_FOLDER, 'hidden_size_'+str(hidden_size)+'.json')

    with open(results_path) as file:
        pom= json.load(file)
        results['rnn'].extend(pom['rnn'])
        results['lstm'].extend(pom['lstm'])
        results['gru'].extend(pom['gru'])

X=np.array([0.5,1, 1.5])
for rnn in rnns:
    accs = []
    f1= []

    for i in range(len(results[rnn])):
        if i%2==0:
            accs.append(results[rnn][i])
        else:
            f1.append(results[rnn][i])

    plt.subplot(4, 3, br_graf)
    plt.bar(X-0.05, accs, color ='c', width=0.1, edgecolor='k', label='acc')
    plt.bar(X+0.05, f1, color ='m', width=0.1, edgecolor='k', label='f1')
    plt.xticks(X, hidden_sizes)
    plt.title("Rezultati za hidden_sizes "+str(rnn.upper()))
    br_graf+=1

results=dict()
results['rnn']=[]
results['lstm']=[]
results['gru']=[]

for bidirectional in bidirectionals:

    results_path = os.path.join(SAVE_FOLDER, 'bidirectional_'+str(bidirectional)+'.json')

    with open(results_path) as file:
        pom= json.load(file)
        results['rnn'].extend(pom['rnn'])
        results['lstm'].extend(pom['lstm'])
        results['gru'].extend(pom['gru'])

X=np.array([0.5,1])
for rnn in rnns:
    accs = []
    f1= []

    for i in range(len(results[rnn])):
        if i%2==0:
            accs.append(results[rnn][i])
        else:
            f1.append(results[rnn][i])

    plt.subplot(4, 3, br_graf)
    plt.bar(X-0.05, accs, color ='c', width=0.1, edgecolor='k', label='acc')
    plt.bar(X+0.05, f1, color ='m', width=0.1, edgecolor='k', label='f1')
    plt.xticks(X, bidirectionals)
    plt.title("Rezultati za bidirectional "+str(rnn.upper()))
    plt.legend()
    br_graf+=1

results=dict()
results['rnn']=[]
results['lstm']=[]
results['gru']=[]

for num_layers in num_layer:

    results_path = os.path.join(SAVE_FOLDER, 'num_layers_'+str(num_layers)+'.json')

    with open(results_path) as file:
        pom= json.load(file)
        results['rnn'].extend(pom['rnn'])
        results['lstm'].extend(pom['lstm'])
        results['gru'].extend(pom['gru'])

X=np.array([0.5,1, 1.5])
for rnn in rnns:
    accs = []
    f1= []

    for i in range(len(results[rnn])):
        if i%2==0:
            accs.append(results[rnn][i])
        else:
            f1.append(results[rnn][i])

    plt.subplot(4, 3, br_graf)
    plt.bar(X-0.05, accs, color ='c', width=0.1, edgecolor='k', label='acc')
    plt.bar(X+0.05, f1, color ='m', width=0.1, edgecolor='k', label='f1')
    plt.xticks(X, num_layer)
    plt.title("Rezultati za num_layers "+str(rnn.upper()))
    br_graf+=1

results=dict()
results['rnn']=[]
results['lstm']=[]
results['gru']=[]

j=1
for dropout in dropouts:

    results_path = os.path.join(SAVE_FOLDER, 'dropouts_'+str(j)+'.json')
    j+=1
    with open(results_path) as file:
        pom= json.load(file)
        results['rnn'].extend(pom['rnn'])
        results['lstm'].extend(pom['lstm'])
        results['gru'].extend(pom['gru'])

X=np.array([0.5,1, 1.5])

for rnn in rnns:
    accs = []
    f1= []

    for i in range(len(results[rnn])):
        if i%2==0:
            accs.append(results[rnn][i])
        else:
            f1.append(results[rnn][i])

    plt.subplot(4, 3, br_graf)
    plt.bar(X-0.05, accs, color ='c', width=0.1, edgecolor='k', label='acc')
    plt.bar(X+0.05, f1, color ='m', width=0.1, edgecolor='k', label='f1')
    plt.xticks(X, dropouts)
    plt.title("Rezultati za dropouts "+str(rnn.upper()))
    br_graf+=1

plt.show()