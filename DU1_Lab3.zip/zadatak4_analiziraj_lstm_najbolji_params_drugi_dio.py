import json
import os

import matplotlib.pyplot as plt
import numpy as np

val_results = dict()
train_results = dict()


SAVE_FOLDER="C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\ZAD4_REZULTATI\\LSTM_BEST"
save_folders=['run1', 'run2', 'run3', 'run4', 'run5']

#dodaj grafove za train i valid u runnovimai za test

print("Za sve provjere koristeni su parametri: param_iter=5, param_delta=1e-4, batch_size=10, grad_clipings=1")
print("Za sve provjere koristeni su hiperparametriparametri: rnn_vrsta='lstm',hidden_size=150, bidirectional=True, num_layers=2, dropout=0.25")


train_accs=[]
train_f1=[]

test_accs=[]
test_f1=[]
for i in range(5):
    print("\nRun "+str(i+1)+":")
    val_results = dict()
    train_results = dict()
    save_folder = os.path.join(SAVE_FOLDER, save_folders[i])
    train_folder = os.path.join(save_folder, 'train_results.json')
    valid_folder = os.path.join(save_folder, 'valid_results.json')

    with open(train_folder) as file:
        train_results=json.load(file)

    with open(valid_folder) as file:
        val_results=json.load(file)

    print("\nZa valid u svakoj epohi:")
    for key, value in val_results.items():
        print(key + ": ", end="")
        print(value)

    print("\nZa train:")
    for key, value in train_results.items():
        print(key + ": " + str(value))

    test_results = dict()
    test_folder = os.path.join(save_folder, 'test_results.json')

    with open(test_folder) as file:
        test_results=json.load(file)

    print("\nZa test:")
    for key, value in test_results.items():
        print(key+": "+str(value))

    train_accs.append(train_results['acc'])
    train_f1.append(train_results['f1'])
    test_accs.append(test_results['acc'])
    test_f1.append(test_results['f1'])



plt.figure(figsize=(20,15))
plt.tight_layout()
br_graf=1
plt.subplots_adjust(hspace=0.5)  # Adjust vertical spacing

X=np.array([0.5,1, 1.5, 2, 2.5])
plt.subplot(2, 1, 1)
plt.bar(X-0.05, train_accs, color ='c', width=0.1, edgecolor='k', label='acc')
plt.bar(X+0.05, train_f1, color ='m', width=0.1, edgecolor='k', label='f1')
plt.xticks(X, save_folders)
plt.title("Rezultati nad train skupom")

plt.subplot(2, 1, 2)
plt.bar(X-0.05, test_accs, color ='c', width=0.1, edgecolor='k', label='acc')
plt.bar(X+0.05, test_f1, color ='m', width=0.1, edgecolor='k', label='f1')
plt.xticks(X, save_folders)
plt.title("Rezultati nad test skupom")
plt.legend(loc='best')
plt.show()