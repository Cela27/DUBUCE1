import numpy as np
import torch
import torch.optim as optim


# racinanje gradijenta u podzadatku
# imamo srednji kvadratni gubitak tj:
# L(Y, Y_pred)=(1/n)*sum(y-y_pred)^2= (1/n)*sum(y-a*x-b)^2
# to deriviramo po parametrima a i b
# dolazim do:
# dL/da=(2/n)*sum(y-a*x-b)*-x=(2/n)*sum(a*x+b-y)*x
# dL/db=(2/n)*sum(y-a*x-b)*-1=(2/n)*sum(a*x+b-y)


def lin_regr(points, Y, param_niter=100, param_delta=0.05):
    ## Definicija računskog grafa
    # podaci i parametri, inicijalizacija parametara
    # Y=a*x+b
    a = torch.randn(1, requires_grad=True)
    b = torch.randn(1, requires_grad=True)

    # optimizacijski postupak: gradijentni spust
    optimizer = optim.SGD([a, b], lr=param_delta)

    for i in range(param_niter):
        # afin regresijski model
        Y_pred = 0
        loss_sum=0
        gradijent_a =0
        gradijent_b = 0
        sum=0
        for X in points:
            Y_pred = a * X + b

            # srednji kvadratni gubitak jer  zelimo da bude ok za vise tocaka
            loss_sum+=torch.square(Y - Y_pred)
            gradijent_a+=((Y_pred - Y) * X)
            gradijent_b+=((Y_pred - Y))
            sum+=1

        gradijent_a= torch.mean(gradijent_a*(2/sum))
        gradijent_b= torch.mean(gradijent_b*(2/sum))

        loss = torch.mean(loss_sum/sum)
        # računanje gradijenata
        loss.backward()
        # korak optimizacije
        optimizer.step()

        print("Itracija " + str(i) + " gubitak je " + str(loss))
        print("Gradijent_a je " + str(a.grad) + ", a moj izracun a gradijanta je " + str(gradijent_a))
        print("Gradijent_b je " + str(b.grad) + ", a moj izracun b gradijanta je " + str(gradijent_b))
        print()

        # Postavljanje gradijenata na nulu
        optimizer.zero_grad()

        print("Finalna predikcija " + str(Y_pred))


X = []
X.append(torch.tensor([1, 2]))
X.append(torch.tensor([2, 4]))
Y = torch.tensor([3, 5])
lin_regr(X, Y)
