import numpy as np
import torch

from zadatak1_metric_dataset import MNISTMetricDataset
from zadatak2_BNReluConv import SimpleMetricEmbedding
from matplotlib import pyplot as plt
from sklearn.decomposition import PCA

def get_colormap():
    colormap = np.zeros((10, 3), dtype=np.uint8)
    colormap[0] = [128, 64, 128]
    colormap[1] = [244, 35, 232]
    colormap[2] = [70, 70, 70]
    colormap[3] = [102, 102, 156]
    colormap[4] = [190, 153, 153]
    colormap[5] = [153, 153, 153]
    colormap[6] = [250, 170, 30]
    colormap[7] = [220, 220, 0]
    colormap[8] = [107, 142, 35]
    colormap[9] = [152, 251, 152]
    return colormap


if __name__ == '__main__':
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"= Using device {device}")
    emb_size = 32
    model = SimpleMetricEmbedding(1, emb_size).to(device)
    # YOUR CODE HERE
    model.load_state_dict(torch.load('zadatak3_model.pth'))
    model.eval()

    colormap = get_colormap()
    mnist_download_root = "./mnist/"
    ds_test = MNISTMetricDataset(mnist_download_root, split='test')
    X = ds_test.images
    Y = ds_test.targets

    print("Fitting PCA directly from images...")
    images = ds_test.images.view(-1, 28 * 28).numpy()
    pca = PCA(n_components=2)
    test_img_rep2d = pca.fit_transform(images)

    group_centroids = []
    unique_groups = np.unique(Y)

    for group in unique_groups:
        group_points = test_img_rep2d[Y == group]
        centroid = np.mean(group_points, axis=0)
        group_centroids.append(centroid)

    plt.scatter(test_img_rep2d[:, 0], test_img_rep2d[:, 1], color=colormap[Y[:]] / 255., s=5)

    for i, centroid in enumerate(group_centroids):
        plt.annotate(unique_groups[i], (centroid[0], centroid[1]), textcoords="offset points", xytext=(0, 10),
                     ha='center',
                     fontsize=12, fontweight='bold', color='red')

    plt.show()

    print("Fitting PCA from feature representation")
    with torch.no_grad():
        model.eval()
        test_rep = model.get_features(X.unsqueeze(1))
        test_rep = test_rep.cpu().numpy()
        pca = PCA(n_components=2)
        test_rep2d = pca.fit_transform(test_rep)

        group_centroids = []
        unique_groups = np.unique(Y)

        for group in unique_groups:
            group_points = test_rep2d[Y == group]
            centroid = np.mean(group_points, axis=0)
            group_centroids.append(centroid)

        plt.scatter(test_rep2d[:, 0], test_rep2d[:, 1], color=colormap[Y[:]] / 255., s=5)

        for i, centroid in enumerate(group_centroids):
            plt.annotate(unique_groups[i], (centroid[0], centroid[1]), textcoords="offset points", xytext=(0, 10),
                         ha='center',
                         fontsize=12, fontweight='bold', color='red')

        plt.show()