import pt_logreg
import pt_deep
import data
import numpy as np
import matplotlib.pyplot as plt
import torch
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import accuracy_score


def comapare_pt_logreg_and_pt_deep():
    np.random.seed(100)
    C = 3
    # instanciraj podatke X i labele Yoh_
    X, Yoh_ = data.sample_gmm_2d(6, C, 10)

    # definiraj model:
    ptlr = pt_logreg.PTLogreg(X.shape[1], C)
    pt_deep_model = pt_deep.PTDeep([2, C], lambda x: pt_deep.sig(x))

    # nauči parametre (X i Yoh_ moraju biti tipa torch.Tensor):
    X_tensor = torch.tensor(X)
    Yoh_tensor = torch.tensor(data.convert_to_one_hot(Yoh_))

    pt_logreg.train(ptlr, X_tensor, Yoh_tensor, 10000, 0.1, 0.01, False)
    pt_deep.train(pt_deep_model, X_tensor, Yoh_tensor, 10000, 0.1, 0.01, False)
    # dohvati vjerojatnosti na skupu za učenje
    probs_ptlr = pt_logreg.eval(ptlr, X)
    probs_ptd = pt_deep.eval(pt_deep_model, X)

    print("Ground truth:" + str(Yoh_))
    print("Logreg:" + str(probs_ptlr)+", tocnost="+str(accuracy_score(Yoh_, probs_ptlr)))
    print("Deep model [2, 3]:" + str(np.argmax(probs_ptd, axis=1))+", tocnost="+str(accuracy_score(Yoh_, np.argmax(probs_ptd, axis=1))))


def isprobaj_razlicite_parametre_deep(K, C, N):
    np.random.seed(100)
    configurations = [[2, C], [2, 10, C], [2, 10, 10, C]]

    # instanciraj podatke X i labele Yoh_
    X, Yoh_ = data.sample_gmm_2d(K, C, N)
    X_tensor = torch.tensor(X)
    Yoh_tensor = torch.tensor(data.convert_to_one_hot(Yoh_))

    i = 1
    plt.figure(figsize=(16, 9))
    for conf in configurations:
        pt_deep_model = pt_deep.PTDeep(conf, lambda x: pt_deep.sig(x))
        pt_deep.train(pt_deep_model, X_tensor, Yoh_tensor, 10000, 0.1, 0.01, False)
        probs_ptd = pt_deep.eval(pt_deep_model, X)

        plt.subplot(3, 2, i)
        rect = np.min(X, axis=0), np.max(X, axis=0)
        data.graph_surface(lambda x: np.argmax(pt_deep.eval(pt_deep_model, x), axis=1), rect, 0.5, 1024, 1024)
        data.graph_data(X, Yoh_, np.argmax(probs_ptd))

        pt_deep_model = pt_deep.PTDeep(conf, lambda x: pt_deep.relu(x))
        pt_deep.train(pt_deep_model, X_tensor, Yoh_tensor, 10000, 0.1, 0.01, False)
        probs_ptd = pt_deep.eval(pt_deep_model, X)

        plt.subplot(3, 2, i + 1)
        rect = np.min(X, axis=0), np.max(X, axis=0)
        data.graph_surface(lambda x: np.argmax(pt_deep.eval(pt_deep_model, x), axis=1), rect, 0.5, 1024, 1024)
        data.graph_data(X, Yoh_, np.argmax(probs_ptd))
        i = i + 2
    plt.show()


comapare_pt_logreg_and_pt_deep()
#isprobaj_razlicite_parametre_deep(4, 2, 40)
#isprobaj_razlicite_parametre_deep(6,2,10)
