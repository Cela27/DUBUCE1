import json
import os

import numpy as np
import torch

import zadatak1_load_data as load_data
import utils
from zadatak4_custom_rnn import CustomRNN

TRAIN_PATH = "C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\DATA\\sst_train.csv"
VALIDATE_PATH = "C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\DATA\\sst_valid.csv"
TEST_PATH = "C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\DATA\\sst_test.csv"
EMBEDDINGS_PATH = "C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\DATA\\sst_glove.txt"
SAVE_FOLDER = "C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\ZAD4_PARAMS"

frekvencije = utils.frekvencije(TRAIN_PATH)
data_vocab = load_data.Vocab(frekvencije=frekvencije, max_size=-1, min_freq=1, additional=True)
label_vocab = load_data.Vocab(frekvencije={"positive": 2, "negative": 1}, max_size=-1, min_freq=1)

emb = utils.get_embedding_matrix(vocab=data_vocab, path=EMBEDDINGS_PATH)

train = load_data.NLPDataset(TRAIN_PATH, data_vocab, label_vocab)
valid = load_data.NLPDataset(VALIDATE_PATH, data_vocab, label_vocab)
test = load_data.NLPDataset(TEST_PATH, data_vocab, label_vocab)

rnns = ['rnn', 'lstm', 'gru']

hidden_sizes = [50, 500, 750]

bidirectionals = [True, False]

num_layer = [1, 2, 5]

dropouts = [0., 0.25, 0.5]

for hidden_size in hidden_sizes:
    results = dict()

    for rnn in rnns:
        model = CustomRNN(rnn_vrsta=rnn, embedding_matrix=emb, hidden_size=hidden_size, freeze=False)

        model.train(dataset=train, validation_dataset=valid, save_folder=None, param_iter=5, param_delta=1e-4,
                    batch_size=10, grad_clip=0.25, ispis=False)

        test_loss, test_precision, test_recall, test_acc, test_f1, test_cm = model.evaluate(test)

        results[rnn]=[test_acc, test_f1]

    results_path = os.path.join(SAVE_FOLDER, 'hidden_size_'+str(hidden_size)+'.json')

    with open(results_path, mode="w+") as file:
        json.dump(results, file,
                  sort_keys=False, ensure_ascii=False, indent=2)

for bidirectional in bidirectionals:
    results = dict()

    for rnn in rnns:
        model = CustomRNN(rnn_vrsta=rnn, embedding_matrix=emb, bidirectional=bidirectional, freeze=False)

        model.train(dataset=train, validation_dataset=valid, save_folder=None, param_iter=5, param_delta=1e-4,
                    batch_size=10, grad_clip=0.25, ispis=False)

        test_loss, test_precision, test_recall, test_acc, test_f1, test_cm = model.evaluate(test)

        results[rnn]=[test_acc, test_f1]

    results_path = os.path.join(SAVE_FOLDER, 'bidirectional_'+str(bidirectional)+'.json')

    with open(results_path, mode="w+") as file:
        json.dump(results, file,
                  sort_keys=False, ensure_ascii=False, indent=2)

for num_layers in num_layer:
    results = dict()

    for rnn in rnns:
        model = CustomRNN(rnn_vrsta=rnn, embedding_matrix=emb, num_layers=num_layers, freeze=False)

        model.train(dataset=train, validation_dataset=valid, save_folder=None, param_iter=5, param_delta=1e-4,
                    batch_size=10, grad_clip=0.25, ispis=False)

        test_loss, test_precision, test_recall, test_acc, test_f1, test_cm = model.evaluate(test)

        results[rnn]=[test_acc, test_f1]

    results_path = os.path.join(SAVE_FOLDER, 'num_layers_'+str(num_layers)+'.json')

    with open(results_path, mode="w+") as file:
        json.dump(results, file,
                  sort_keys=False, ensure_ascii=False, indent=2)

i=1
for dropout in dropouts:
    results = dict()

    for rnn in rnns:
        model = CustomRNN(rnn_vrsta=rnn, embedding_matrix=emb, dropout=dropout, freeze=False)

        model.train(dataset=train, validation_dataset=valid, save_folder=None, param_iter=5, param_delta=1e-4,
                    batch_size=10, grad_clip=0.25, ispis=False)

        test_loss, test_precision, test_recall, test_acc, test_f1, test_cm = model.evaluate(test)

        results[rnn]=[test_acc, test_f1]

    results_path = os.path.join(SAVE_FOLDER, 'dropouts_'+str(i)+'.json')
    i+=1
    with open(results_path, mode="w+") as file:
        json.dump(results, file,
                  sort_keys=False, ensure_ascii=False, indent=2)