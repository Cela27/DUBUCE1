import json
import os

import numpy as np
import torch.nn
from sklearn.metrics import confusion_matrix, precision_score, recall_score, accuracy_score

import utils


class CustomRNN(torch.nn.Module):

    def __init__(self, embedding_matrix, rnn_vrsta="rnn", hidden_size=150, num_layers=2, dropout=0.,
                 bidirectional=False, freeze=True):

        super().__init__()

        if isinstance(embedding_matrix, int):
            self.embedding = torch.nn.Embedding(num_embeddings=embedding_matrix, embedding_dim=300, padding_idx=0)
        else:
            self.embedding = torch.nn.Embedding.from_pretrained(torch.tensor(embedding_matrix), freeze=freeze,
                                                                padding_idx=0)

        if bidirectional:
            hidden_size = 2 * hidden_size

        if rnn_vrsta == "rnn":
            self.rnn1 = torch.nn.RNN(300, hidden_size, num_layers=num_layers, dropout=dropout)
            self.rnn2 = torch.nn.RNN(hidden_size, hidden_size, num_layers=num_layers, dropout=dropout)

        if rnn_vrsta == "lstm":
            self.rnn1 = torch.nn.LSTM(300, hidden_size, num_layers=num_layers, dropout=dropout)
            self.rnn2 = torch.nn.LSTM(hidden_size, hidden_size, num_layers=num_layers, dropout=dropout)

        if rnn_vrsta == "gru":
            self.rnn1 = torch.nn.GRU(300, hidden_size, num_layers=num_layers, dropout=dropout)
            self.rnn2 = torch.nn.GRU(hidden_size, hidden_size, num_layers=num_layers, dropout=dropout)

        self.fc1 = torch.nn.Linear(hidden_size, 150, bias=True)
        self.fc2 = torch.nn.Linear(150, 1, bias=True)

        self.loss = torch.nn.BCEWithLogitsLoss()
        self.reset_parameters()

    def reset_parameters(self):
        # kaiming_normal_ kad su relu aktivacijske, a xavier za sigmoide i zadnje slojeve
        # LSTM koristi tahn sto je slicno sigm??

        if isinstance(self.rnn1, torch.nn.RNN) or isinstance(self.rnn1, torch.nn.LSTM) \
                or isinstance(self.rnn1, torch.nn.GRU):
            for name, param in self.rnn1.named_parameters():
                if 'weight' in name:
                    torch.nn.init.xavier_normal_(param)
                elif 'bias' in name:
                    torch.nn.init.constant_(param, 0.)

        if isinstance(self.rnn2, torch.nn.RNN) or isinstance(self.rnn2, torch.nn.LSTM) \
                or isinstance(self.rnn2, torch.nn.GRU):
            for name, param in self.rnn2.named_parameters():
                if 'weight' in name:
                    torch.nn.init.xavier_normal_(param)
                elif 'bias' in name:
                    torch.nn.init.constant_(param, 0.)

        if isinstance(self.fc1, torch.nn.Linear):
            torch.nn.init.kaiming_normal_(self.fc1.weight, mode='fan_in', nonlinearity='relu')
            torch.nn.init.constant_(self.fc1.bias, 0)

        if isinstance(self.fc2, torch.nn.Linear):
            torch.nn.init.xavier_normal_(self.fc2.weight)
            torch.nn.init.constant_(self.fc2.bias, 0.)

    def forward(self, x):
        # x je batch_size * recenica_duljina

        # emb je batch_size * recenica_duljina * emb_size

        emb = self.embedding(x)
        # lstm ulaz mora bit recenica_duljina*batch_size*emb_size
        emb = torch.transpose(emb, 0, 1)

        h1, hidden = self.rnn1(emb)
        h2, hidden = self.rnn2(h1)

        zadnje_skriveno_stanje = h2[-1]

        h3 = self.fc1(zadnje_skriveno_stanje)
        h3 = torch.relu(h3)

        y = self.fc2(h3)

        return y

    def train(self, dataset, validation_dataset, save_folder, param_iter=5, param_delta=1e-4, batch_size=10,
              grad_clip=1.0, ispis=False):
        validations = dict()
        validations['loss'] = list()
        validations['acc'] = list()
        validations['f1'] = list()
        validations['cm'] = list()

        losses = list()

        optimizer = torch.optim.Adam(self.parameters(), lr=param_delta)

        for i in range(param_iter):
            loss_memory = list()

            dataloader = torch.utils.data.DataLoader(dataset=dataset, batch_size=batch_size, shuffle=True,
                                                     collate_fn=utils.pad_collate)
            for j, batch in enumerate(dataloader):
                loss = self.loss(self.forward(batch[0]).squeeze(-1), batch[1].float())
                loss.backward()

                loss_memory.append(float(loss))

                torch.nn.utils.clip_grad_norm_(self.parameters(), grad_clip)

                optimizer.step()
                optimizer.zero_grad()

            if ispis:
                print("U epohi " + str(i + 1) + " na valid skupu gubitak je " + str(np.mean(loss_memory)))

            with torch.no_grad():
                losses.append(np.mean(loss_memory))
                val_loss, val_precision, val_recall, val_acc, val_f1, val_cm = self.evaluate(validation_dataset)
                if ispis:
                    print("\nTočnost:" + str(val_acc) + "\n\nPreciznost:" + str(val_precision)
                          + "\n\nOdziv:" + str(val_recall) + "\n\nf1:" + str(val_f1))
                    print()

                validations['loss'].append(val_loss)
                validations['acc'].append(val_acc)
                validations['f1'].append(val_f1)
                validations['cm'].append(val_cm.tolist())

        if save_folder is not None:
            train_path = os.path.join(save_folder, "train_results.json")
            valid_path = os.path.join(save_folder, "valid_results.json")

            train_loss, train_precision, train_recall, train_acc, train_f1, train_cm = self.evaluate(dataset)
            train_results = dict()

            train_results['loss'] = train_loss
            train_results['acc'] = train_acc
            train_results['f1'] = train_f1
            train_results['cm'] = train_cm.tolist()

            with open(train_path, mode="w+") as file:
                json.dump(train_results, file,
                          sort_keys=False, ensure_ascii=False, indent=2)

            with open(valid_path, mode="w+") as file:
                json.dump(validations, file,
                          sort_keys=False, ensure_ascii=False, indent=2)

    def evaluate(self, dataset):
        dataloader = torch.utils.data.DataLoader(dataset=dataset, batch_size=1, shuffle=False,
                                                 collate_fn=utils.pad_collate)

        x = []
        y = []
        for entry in dataloader:
            x.append(entry[0])
            y.append(entry[1])

        y_pred = list()
        losses = list()

        for x_pom, y_pom in zip(x, y):
            # with torch.no_grad():
            y_p = torch.sigmoid(self.forward(x_pom))
            y_p = y_p.round().int().squeeze(-1)
            y_pred.append(int(y_p))
            y_pred_tensor = torch.tensor(y_pred[-1]).float().view(y_pom.shape)
            losses.append(float(self.loss(y_pom.float(), y_pred_tensor)))

        concatenated_tensor = torch.cat(y, dim=0)
        y = concatenated_tensor.detach().numpy()

        y = np.array(y, dtype=np.int32)
        y_pred = np.array(y_pred, dtype=np.int32)
        cm = confusion_matrix(y, y_pred)

        precision = precision_score(y, y_pred, average='macro')
        recall = recall_score(y, y_pred, average='macro')
        accuracy = accuracy_score(y, y_pred)
        f1 = (2 * precision * recall) / (precision + recall)

        return np.mean(losses), precision, recall, accuracy, f1, cm
