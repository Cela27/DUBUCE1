import pt_logreg
import data
import numpy as np
import matplotlib.pyplot as plt
import torch
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import accuracy_score

def ispis(Yoh_, probs):
    # ispiši performansu (preciznost i odziv po razredima)
    print("Preciznost modela je: "
              +str(precision_score(Yoh_, probs, average=None, zero_division=0)))
    print("Odziva modela je: "+
              str(recall_score(Yoh_, probs, average=None, zero_division=0)))
    print("Tocnost modela je: "+ str(accuracy_score(Yoh_, probs)))


# inicijaliziraj generatore slučajnih brojeva
np.random.seed(100)
C = 3
# instanciraj podatke X i labele Yoh_
X, Yoh_ = data.sample_gmm_2d(6, C, 10)

# definiraj model:
ptlr = pt_logreg.PTLogreg(X.shape[1], C)

# nauči parametre (X i Yoh_ moraju biti tipa torch.Tensor):
X_tensor = torch.tensor(X)
Yoh_tensor = torch.tensor(data.convert_to_one_hot(Yoh_))

param_numiter=10000
param_delta=0.05
param_lambda=0.01

pt_logreg.train(ptlr, X_tensor, Yoh_tensor, param_numiter, param_delta, param_lambda, False)
# dohvati vjerojatnosti na skupu za učenje
probs = pt_logreg.eval(ptlr, X)
#ispis
print("Parametri su: delta="+str(param_delta)+", lambda="+str(param_lambda))
ispis(Yoh_, probs)
print()

param_delta=0.05
param_lambda=0.1

pt_logreg.train(ptlr, X_tensor, Yoh_tensor, param_numiter, param_delta, param_lambda, False)
# dohvati vjerojatnosti na skupu za učenje
probs = pt_logreg.eval(ptlr, X)
print("Parametri su: delta="+str(param_delta)+", lambda="+str(param_lambda))
ispis(Yoh_, probs)
print()

param_delta=0.05
param_lambda=1

pt_logreg.train(ptlr, X_tensor, Yoh_tensor, param_numiter, param_delta, param_lambda, False)
# dohvati vjerojatnosti na skupu za učenje
probs = pt_logreg.eval(ptlr, X)
print("Parametri su: delta="+str(param_delta)+", lambda="+str(param_lambda))
ispis(Yoh_, probs)
print()

param_delta=0.1
param_lambda=0.1

pt_logreg.train(ptlr, X_tensor, Yoh_tensor, param_numiter, param_delta, param_lambda, False)
# dohvati vjerojatnosti na skupu za učenje
probs = pt_logreg.eval(ptlr, X)
print("Parametri su: delta="+str(param_delta)+", lambda="+str(param_lambda))
ispis(Yoh_, probs)

param_delta=0.1
param_lambda=0.01

pt_logreg.train(ptlr, X_tensor, Yoh_tensor, param_numiter, param_delta, param_lambda, False)
# dohvati vjerojatnosti na skupu za učenje
probs = pt_logreg.eval(ptlr, X)
print("Parametri su: delta="+str(param_delta)+", lambda="+str(param_lambda))
ispis(Yoh_, probs)

