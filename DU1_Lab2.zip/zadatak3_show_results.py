from pathlib import Path
import torch
from torchvision.datasets import MNIST
import numpy as np
import json
import matplotlib.pyplot as plt
import zadatak3

DATA_DIR = Path(__file__).parent / "datasets" / "MNIST"
MODEL_PATH = Path(__file__).parent / "out_zad3" / "conv_model.pth"
TRAIN_LOSSES_PATH = Path(__file__).parent / "out_zad3" / "train_losses.json"
VAL_LOSSES_PATH = Path(__file__).parent / "out_zad3" / "validate_losses.json"


def convert_to_one_hot_minst(data):
    converted = list()

    for example in data:
        primjer = np.zeros(10)
        primjer[example.data] = 1.

        converted.append(primjer)
    converted = np.asarray(converted)
    return converted


def load_data():
    ds_train, ds_test = MNIST(DATA_DIR, train=True, download=True), MNIST(DATA_DIR, train=False)
    train_x = ds_train.data.reshape([-1, 1, 28, 28]).numpy().astype(np.float) / 255
    train_y = ds_train.targets.numpy()
    train_x, valid_x = train_x[:55000], train_x[55000:]
    train_y, valid_y = train_y[:55000], train_y[55000:]
    test_x = ds_test.data.reshape([-1, 1, 28, 28]).numpy().astype(np.float) / 255
    test_y = ds_test.targets.numpy()
    train_mean = train_x.mean()
    train_x, valid_x, test_x = (x - train_mean for x in (train_x, valid_x, test_x))
    train_y, valid_y, test_y = (convert_to_one_hot_minst(y) for y in (train_y, valid_y, test_y))
    return train_x, valid_x, test_x, train_y, valid_y, test_y


train_x, valid_x, test_x, train_y, valid_y, test_y = load_data()
train_x = train_x.astype('float32')
valid_x = valid_x.astype('float32')
test_x = test_x.astype('float32')

train_x = torch.tensor(train_x)
valid_x = torch.tensor(valid_x)
test_x = torch.tensor(test_x)

train_y = train_y.astype('float32')
valid_y = valid_y.astype('float32')
test_y = test_y.astype('float32')

train_y = torch.tensor(train_y)
valid_y = torch.tensor(valid_y)
test_y = torch.tensor(test_y)

net = zadatak3.ConvolutionalModel(in_channels=1, conv1_width=16, fc1_width=512, class_count=10)
net.load_state_dict(torch.load(MODEL_PATH))

print("Rezulatati na test skupu za model iz 3. zadatka:")
zadatak3.evaluate(net, test_x, test_y)


with open(TRAIN_LOSSES_PATH) as json_file:
    train_losses = json.load(json_file)

with open(VAL_LOSSES_PATH) as json_file:
    validate_losses = json.load(json_file)

plt.plot(range(1, len(train_losses)+1), train_losses, label='Gubitak na train skupu kroz epohe')
plt.plot(range(1, len(validate_losses) + 1),validate_losses, label='Gubitak na validate skupu kroz epohe')
plt.legend()
plt.show()
