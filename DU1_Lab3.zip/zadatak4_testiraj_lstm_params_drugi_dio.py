import json
import os

import numpy as np
import torch

import zadatak1_load_data as load_data
import utils
from zadatak4_custom_rnn import CustomRNN

TRAIN_PATH = "C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\DATA\\sst_train.csv"
VALIDATE_PATH = "C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\DATA\\sst_valid.csv"
TEST_PATH = "C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\DATA\\sst_test.csv"
EMBEDDINGS_PATH = "C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\DATA\\sst_glove.txt"
SAVE_FOLDER = "C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\ZAD4_PARAMS\\LSTM"

vocab_sizes = [1000, 5000, 10000]
batch_sizes = [5, 32, 64]
freezes = [True, False]
pools = ['min', 'max', 'avg']
grad_clipings = [0.1, 0.5, 1]

frekvencije = utils.frekvencije(TRAIN_PATH)

for vocab_size in vocab_sizes:
    data_vocab = load_data.Vocab(frekvencije=frekvencije, max_size=vocab_size, min_freq=1, additional=True)
    label_vocab = load_data.Vocab(frekvencije={"positive": 2, "negative": 1}, max_size=vocab_size, min_freq=1)

    emb = utils.get_embedding_matrix(vocab=data_vocab, path=EMBEDDINGS_PATH)

    train = load_data.NLPDataset(TRAIN_PATH, data_vocab, label_vocab)
    valid = load_data.NLPDataset(VALIDATE_PATH, data_vocab, label_vocab)
    test = load_data.NLPDataset(TEST_PATH, data_vocab, label_vocab)

    model = CustomRNN(embedding_matrix=emb, rnn_vrsta='lstm', freeze=False)
    model.train(dataset=train, validation_dataset=valid, save_folder=None, param_iter=5, param_delta=1e-4,
                batch_size=10,  ispis=False)

    test_loss, test_precision, test_recall, test_acc, test_f1, test_cm = model.evaluate(test)

    results = [test_acc, test_f1]

    results_path = os.path.join(SAVE_FOLDER, 'vocab_size_' + str(vocab_size) + '.json')

    with open(results_path, mode="w+") as file:
        json.dump(results, file,
                  sort_keys=False, ensure_ascii=False, indent=2)

data_vocab = load_data.Vocab(frekvencije=frekvencije, max_size=-1, min_freq=1, additional=True)
label_vocab = load_data.Vocab(frekvencije={"positive": 2, "negative": 1}, max_size=-1, min_freq=1)

emb = utils.get_embedding_matrix(vocab=data_vocab, path=EMBEDDINGS_PATH)
train = load_data.NLPDataset(TRAIN_PATH, data_vocab, label_vocab)
valid = load_data.NLPDataset(VALIDATE_PATH, data_vocab, label_vocab)
test = load_data.NLPDataset(TEST_PATH, data_vocab, label_vocab)

for batch_size in batch_sizes:
    model = CustomRNN(embedding_matrix=emb, rnn_vrsta='lstm', freeze=False)

    model.train(dataset=train, validation_dataset=valid, save_folder=None, param_iter=5, param_delta=1e-4,
                batch_size=batch_size, ispis=False)

    test_loss, test_precision, test_recall, test_acc, test_f1, test_cm = model.evaluate(test)

    results = [test_acc, test_f1]

    results_path = os.path.join(SAVE_FOLDER, 'batch_size_' + str(batch_size) + '.json')

    with open(results_path, mode="w+") as file:
        json.dump(results, file,
                  sort_keys=False, ensure_ascii=False, indent=2)

for freeze in freezes:
    model = CustomRNN(embedding_matrix=emb, rnn_vrsta='lstm', freeze=freeze)

    model.train(dataset=train, validation_dataset=valid, save_folder=None, param_iter=5, param_delta=1e-4,
                batch_size=10, ispis=False)

    test_loss, test_precision, test_recall, test_acc, test_f1, test_cm = model.evaluate(test)

    results = [test_acc, test_f1]

    results_path = os.path.join(SAVE_FOLDER, 'freeze_' + str(freeze) + '.json')

    with open(results_path, mode="w+") as file:
        json.dump(results, file,
                  sort_keys=False, ensure_ascii=False, indent=2)

i = 1
for grad_cliping in grad_clipings:
    model = CustomRNN(embedding_matrix=emb, rnn_vrsta='lstm', freeze=False)

    model.train(dataset=train, validation_dataset=valid, save_folder=None, param_iter=5, param_delta=1e-4,
                batch_size=10, grad_clip=grad_cliping, ispis=False)

    test_loss, test_precision, test_recall, test_acc, test_f1, test_cm = model.evaluate(test)

    results = [test_acc, test_f1]

    results_path = os.path.join(SAVE_FOLDER, 'grad_cliping_' + str(i) + '.json')
    i += 1
    with open(results_path, mode="w+") as file:
        json.dump(results, file,
                  sort_keys=False, ensure_ascii=False, indent=2)
