import numpy as np
import matplotlib.pyplot as plt
import data
from sklearn.preprocessing import StandardScaler

class FCANN2:
    w=[]
    bias=[]

    def __init__(self, input, hidden, N):
        w = []
        bias = []
        pom = np.random.normal(loc=0,scale=np.reciprocal(np.mean([input, hidden])) ,size=(input, hidden))
        bias.append(np.zeros([1, hidden]))
        w.append(pom)

        pom = np.random.normal(loc=0,scale=np.reciprocal(np.mean([hidden, N])) ,size=(hidden, N))
        bias.append(np.zeros([1, N]))
        w.append(pom)

        FCANN2.w=w
        FCANN2.bias=bias

    def fcann2_train(self, X, Y,  num_iter=10000, param_delta = 0.05, param_lambda=0.001):


        for i in range(1, num_iter+1):
            #in layer sa sljedecim
            s = X@FCANN2.w[0] + FCANN2.bias[0]
            #relu
            h = np.maximum(0., s)
            #hiddeen layer
            s=h@FCANN2.w[1] + FCANN2.bias[1]
            #softmax
            exp = np.exp(s)
            sum_exp = np.sum(exp, axis=1)
            outputs = exp / sum_exp[:, np.newaxis]

            #gubitak
            predikcija_tocnosti = []

            #tu
            for j in range(0, len(outputs)):
                if Y[j].argmax(axis=-1)==1:
                    predikcija_tocnosti.append(outputs[j][1])
                elif Y[j].argmax(axis=-1)==0:
                    predikcija_tocnosti.append(outputs[j][0])

            log_loss = -np.mean(np.log(predikcija_tocnosti))

            #regularizacija, norm?
            regularizacija = param_lambda * np.mean(np.sqrt([np.sum(np.square(x)) for x in FCANN2.w]))
            loss= log_loss + regularizacija

            if i%5000==0:
                print("Iteracija: "+ str(i)+ " s gubiotkom "+str(loss))

            gradijent_izlaznog_sloja = []

            #za stupca Y=1 oduzmi 1: Gs2=Pi-Yi=dL1/dS2
            for j in range(0, len(outputs)):
                if Y[j].argmax()==0:
                    gradijent_izlaznog_sloja.append([(outputs[j][0]-1)/len(X), outputs[j][1]/len(X)])
                elif Y[j].argmax()==1:
                    gradijent_izlaznog_sloja.append([outputs[j][0]/len(X), (outputs[j][1]-1)/len(X)])

            #grad(b2)=sum(dL/db2)=sum(grad(w2))
            gradijent_bias_izlaznog_sloja = np.sum(gradijent_izlaznog_sloja, axis=0)

            #to*h tj. grad(W2)=H*Gs2,
            gradijent_tezina_izlaznog_sloja = h.T@gradijent_izlaznog_sloja

            #dL1/dS1=(Pi-Yi)*W2
            grad_skrivenog_sloja = gradijent_izlaznog_sloja @ FCANN2.w[1].T
            #*dig[s1>0],tj sve manje od 0 stavljam na 0
            grad_skrivenog_sloja[h <= 0.] = 0.

            #ulaz*grad skrivenog sloja
            gradijent_tezina_skrivenog_sloja = X.T@grad_skrivenog_sloja
            gradijent_bias_skrivenog_sloja = np.sum(grad_skrivenog_sloja, axis=0)

            #modificiranje tezina i biasa
            FCANN2.w[0] -= param_delta * gradijent_tezina_skrivenog_sloja
            FCANN2.bias[0] -= param_delta * gradijent_bias_skrivenog_sloja
            FCANN2.w[1] -= param_delta * gradijent_tezina_izlaznog_sloja
            FCANN2.bias[1] -= param_delta * gradijent_bias_izlaznog_sloja

    def fcann2_classify(self, X):

        X = np.array(X)

        # in layer sa sljedecim
        s = X @ FCANN2.w[0] + FCANN2.bias[0]
        # relu
        h = np.maximum(0., s)

        # hiddeen layer
        s = h @ FCANN2.w[1] + FCANN2.bias[1]
        # softmax
        exp = np.exp(s)
        sum_exp = np.sum(exp, axis=1)
        outputs = exp / sum_exp[:, np.newaxis]

        return np.argmax(outputs, axis=1)

if __name__ == "__main__":
    np.random.seed(150)
    X, Y = data.sample_gmm_2d(6, 2, 10)
    Y_ = data.convert_to_one_hot(Y)

    rect = np.min(X, axis=0), np.max(X, axis=0)
    param_niter = 100000
    param_delta = 0.05
    param_lambda = 1e-3

    model = FCANN2(2,48, 2)
    model.fcann2_train(X, Y_, param_niter, param_delta, param_lambda)
    figure=plt.figure(figsize=(16, 9))

    data.graph_surface(model.fcann2_classify, rect, 0.5, 1024, 1024)
    data.graph_data(X, Y, model.fcann2_classify(X))
    plt.show()