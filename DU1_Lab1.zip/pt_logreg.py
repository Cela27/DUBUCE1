import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import data
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score

class PTLogreg(nn.Module):
    def __init__(self, D, C):
        """Arguments:
           - D: dimensions of each datapoint
           - C: number of classes
        """
        super().__init__()

        # inicijalizirati parametre (koristite nn.Parameter):
        # imena mogu biti self.W, self.b

        self.w = nn.Parameter(torch.randn((D, C)), requires_grad=True)
        self.bias = nn.Parameter(torch.zeros(C), requires_grad=True)

    def forward(self, X):
        # unaprijedni prolaz modela: izračunati vjerojatnosti
        #   koristiti: torch.mm, torch.softmax

        h = torch.mm(X.float(), self.w.float()) + self.bias.float()
        probs = torch.softmax(h, dim=1)
        return probs

    def get_loss(self, X, Yoh_):
        # formulacija gubitka
        #   koristiti: torch.log, torch.mean, torch.sum

        outputs = self.forward(X)
        # mozda nastane nan provjeri to
        # srednji logisticki gubitak

        logs = torch.log(outputs) * Yoh_
        sums = torch.sum(logs, dim=1)
        loss = torch.mean(sums)

        return -loss


def train(model, X, Yoh_, param_niter, param_delta, param_lambda, ispis):
    """Arguments:
           - X: model inputs [NxD], type: torch.Tensor
           - Yoh_: ground truth [NxC], type: torch.Tensor
           - param_niter: number of training iterations
           - param_delta: learning rate
        """

    # inicijalizacija optimizatora
    optimizer = torch.optim.SGD(params=model.parameters(), lr=param_delta)

    # petlja učenja
    # ispisujte gubitak tijekom učenja
    for i in range(1, param_niter+1):
        loss = model.get_loss(X, Yoh_) + param_lambda * torch.norm(model.w)

        # računanje gradijenata
        loss.backward()

        # korak optimizacije
        optimizer.step()

        # Postavljanje gradijenata na nulu
        optimizer.zero_grad()

        if i % 1000 == 0 and ispis:
            print("U iteraciji " + str(i) + " gubitak je " + str(loss))


def eval(model, X):
    """Arguments:
           - model: type: PTLogreg
           - X: actual datapoints [NxD], type: np.array
           Returns: predicted class probabilites [NxC], type: np.array
        """
    # ulaz je potrebno pretvoriti u torch.Tensor
    inputs = torch.tensor(X, requires_grad=True)

    # izlaze je potrebno pretvoriti u numpy.array
    # koristite torch.Tensor.detach() i torch.Tensor.numpy()
    outputs = np.argmax(model.forward(inputs).detach().cpu().numpy(), axis=1)

    return outputs


if __name__ == "__main__":
    # inicijaliziraj generatore slučajnih brojeva
    np.random.seed(100)

    C = 2

    # instanciraj podatke X i labele Yoh_
    X, Yoh_ = data.sample_gmm_2d(4, C, 40)

    # definiraj model:
    ptlr = PTLogreg(X.shape[1], C)

    # nauči parametre (X i Yoh_ moraju biti tipa torch.Tensor):

    X_tensor = torch.tensor(X)
    Yoh_tensor = torch.tensor(data.convert_to_one_hot(Yoh_))

    train(ptlr, X_tensor, Yoh_tensor, 10000, 0.05, 0.01, True)

    # dohvati vjerojatnosti na skupu za učenje
    probs = eval(ptlr, X)

    # ispiši performansu (preciznost i odziv po razredima)
    print("Preciznost modela je: "
          +str(precision_score(Yoh_, probs, average=None)))

    print("Odziva modela je: "+
          str(recall_score(Yoh_, probs, average=None)))

    # iscrtaj rezultate, decizijsku plohu
    plt.figure(figsize=(16, 9))
    rect = np.min(X, axis=0), np.max(X, axis=0)
    data.graph_surface(lambda x: eval(ptlr, x), rect, 0.5, 1024, 1024)
    data.graph_data(X, Yoh_, probs)

    plt.show()