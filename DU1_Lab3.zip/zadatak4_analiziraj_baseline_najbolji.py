import json
import os

val_results = dict()
train_results = dict()


SAVE_FOLDER="C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\ZAD4_REZULTATI\\BASELINE"
save_folders=['run1', 'run2', 'run3', 'run4', 'run5']
print("Za sve provjere koristeni su parametri: param_iter=5, param_delta=1e-3, batch_size=5, freeze=False, "
      "vocab_size=5000, pool=avg")
for i in range(5):
    print("\nRun "+str(i+1)+":")
    val_results = dict()
    train_results = dict()
    save_folder = os.path.join(SAVE_FOLDER, save_folders[i])
    train_folder = os.path.join(save_folder, 'train_results.json')
    valid_folder = os.path.join(save_folder, 'valid_results.json')

    with open(train_folder) as file:
        train_results=json.load(file)

    with open(valid_folder) as file:
        val_results=json.load(file)
    '''
    print("\nZa valid u svakoj epohi:")
    for key, value in val_results.items():
        print(key + ": ", end="")
        print(value)

    print("\nZa train:")
    for key, value in train_results.items():
        print(key + ": " + str(value))
    '''
    test_results = dict()
    test_folder = os.path.join(save_folder, 'test_results.json')

    with open(test_folder) as file:
        test_results=json.load(file)

    print("\nZa test:")
    for key, value in test_results.items():
        print(key+": "+str(value))