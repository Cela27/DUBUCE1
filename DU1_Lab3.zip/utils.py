import csv
import numpy as np
import torch
from torch.nn.utils.rnn import pad_sequence

import zadatak1_load_data as load_data


def tokenize(sentence):
    return sentence.split()


def get_instances(dataset):
    instances = []
    with open(dataset) as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            instances.append(load_data.Instance(row[0], row[1]))

    return instances


def frekvencije(dataset):
    instances = get_instances(dataset)

    frekvencije_dict = dict()

    for instance in instances:
        for word in instance.sentence.split():
            if word in frekvencije_dict:
                frekvencije_dict[word] += 1
            else:
                frekvencije_dict[word] = 1

    return frekvencije_dict


def get_embedding_matrix(vocab, path=None, vector_len=300):
    embedding_dict = dict()

    if path is not None:
        with open(path) as file:
            for line in file.readlines():
                line_tokens = line.split()
                word = line_tokens[0]
                vector = np.array([float(x) for x in line_tokens[1:]])
                embedding_dict[word] = vector

    words = [x[0] for x in sorted(vocab.stoi.items(), key=lambda x: x[1])]
    embedding_matrix = np.random.normal(loc=0,
                                        scale=1,
                                        size=(len(words), vector_len))

    if len(embedding_dict) == 0:
        if vector_len is None or vector_len < 1:
            vector_len = 300
    else:
        vector_len = len(list(embedding_dict.values())[0])

    for i, word in enumerate(words):
        if word == "<PAD>":
            embedding_matrix[i] = np.zeros(vector_len)
        elif word in embedding_dict:
            embedding_matrix[i] = embedding_dict[word]

    return embedding_matrix.astype(np.float32)


def pad_collate(batch, padding_value: int = 0):
    texts, labels = zip(*batch)

    padded_texts = pad_sequence(texts, batch_first=True, padding_value=padding_value)
    labels = torch.tensor(labels)
    lengths = torch.tensor([len(element) for element in texts])

    return padded_texts, labels, lengths
