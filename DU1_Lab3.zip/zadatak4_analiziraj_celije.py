import json
import os
import matplotlib.pyplot as plt
import numpy as np

SAVE_FOLDER="C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\ZAD4_REZULTATI"
rnns = ['rnn', 'lstm', 'gru']

print("Za sve provjere koristeni su parametri: param_iter=5, param_delta=1e-4, batch_size=10, grad_clipings=0.25")
print("Za sve provjere koristeni su hiperparametri: hidden_size=150, num_layers=2, dropout=0, bidirectional=False")

rnn = os.path.join(SAVE_FOLDER, 'rnn.json')
lstm = os.path.join(SAVE_FOLDER, 'lstm.json')
gru = os.path.join(SAVE_FOLDER, 'gru.json')

with open(rnn) as file:
    rnn_results=list(json.load(file).values())

with open(lstm) as file:
    lstm_results=list(json.load(file).values())

with open(gru) as file:
    gru_results=list(json.load(file).values())

plt.figure(figsize=(6,4))
X=np.array([0.5,1])
plt.bar(X-0.1, rnn_results, color ='c', width=0.1, edgecolor='k', label='rnn')
plt.bar(X, lstm_results, color ='m', width=0.1, edgecolor='k', label='lstm')
plt.bar(X+0.1, gru_results, color ='y', width=0.1, edgecolor='k', label='gru')
plt.xticks(X, ['acc', 'f1'])
plt.legend()
plt.show()