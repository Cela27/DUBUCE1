import torch
from torch import nn


class IdentityModel(nn.Module):
    def __init__(self):
        super(IdentityModel, self).__init__()

    def get_features(self, img):
        feats = torch.flatten(img, start_dim=1)
        return feats
