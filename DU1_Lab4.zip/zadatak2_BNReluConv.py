import torch
import torch.nn as nn
import torch.nn.functional as F


class _BNReluConv(nn.Sequential):
    def __init__(self, num_maps_in, num_maps_out, k=3, bias=True):
        super(_BNReluConv, self).__init__()

        self.append(nn.BatchNorm2d(num_maps_in))
        self.append(nn.ReLU())
        self.append(nn.Conv2d(num_maps_in, num_maps_out, kernel_size=k, bias=bias))


class SimpleMetricEmbedding(nn.Module):

    def __init__(self, input_channels, emb_size=32):
        super().__init__()
        self.emb_size = emb_size
        self.bn1 = _BNReluConv(input_channels, emb_size, k=3)
        self.pool1 = nn.MaxPool2d(kernel_size=3, stride=2)
        self.bn2 = _BNReluConv(emb_size, emb_size,k=3)
        self.pool2 = nn.MaxPool2d(kernel_size=3, stride=2)
        self.bn3 = _BNReluConv(emb_size, emb_size, k=3)
        self.pool3 = nn.AdaptiveAvgPool2d(1)

    def get_features(self, img):
        # vraca BATCH_SIZE * EMB_SIZE
        h1 = self.bn1(img)
        h1 = self.pool1(h1)

        h2 = self.bn2(h1)
        h2 = self.pool1(h2)

        h3 = self.bn3(h2)

        x = self.pool3(h3)
        x = x.view(x.size(0), -1)
        return x

    def loss(self, anchor, positive, negative, margin=1.0):
        a_x = self.get_features(anchor)
        p_x = self.get_features(positive)
        n_x = self.get_features(negative)

        loss = torch.relu(torch.norm(a_x - p_x, p=2, dim=1) - torch.norm(a_x - n_x, p=2, dim=1) + margin)
        loss = torch.mean(loss)
        return loss
