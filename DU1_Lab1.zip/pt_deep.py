import numpy as np
import torch
from torch import nn
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import accuracy_score
import data
import matplotlib.pyplot as plt

#moras usporedit i testirat jos

class PTDeep(nn.Module):
    def __init__(self, configuration_list, activation):
        super().__init__()

        list_of_weights = []
        list_of_biases = []

        for i in range(0, len(configuration_list)-1):
            list_of_weights.append(
                nn.Parameter(torch.randn((configuration_list[i], configuration_list[i + 1])), requires_grad=True))
            list_of_biases.append(nn.Parameter(torch.zeros(configuration_list[i + 1]), requires_grad=True))

        self.weights = nn.ParameterList(list_of_weights)
        self.biases = nn.ParameterList(list_of_biases)
        self.activation = activation

    def forward(self, X):
        pom = X
        for i in range(0, len(self.weights)):
            h = torch.mm(pom.float(), self.weights[i].float()) + self.biases[i]
            pom = self.activation(h)

        probs = torch.softmax(pom, dim=1)

        return probs

    def get_loss(self, X, Yoh_):
        outputs = self.forward(X)

        # srednji logisticki gubitak
        logs = torch.log(outputs+1e-13) * Yoh_
        sums = torch.sum(logs, dim=1)
        loss = torch.mean(sums)

        return -loss

    def count_params(self):
        imena = []
        parametri = []

        for name, parameter in self.named_parameters():
            imena.append(name)
            # mozda ih moram vadit ili nes
            parametri.append(parameter)

        # drukcije napisi to kad vidis kak izgleda
        br_parametara = sum(p.numel() for p in self.parameters())
        return {"Slojevi": imena, "element_count": br_parametara}


def train(model, X, Yoh_, param_niter, param_delta, param_lambda, ispis):
    optimizer = torch.optim.SGD(params=model.parameters(), lr=param_delta, weight_decay=param_lambda)

    for i in range(1, param_niter + 1):
        loss = model.get_loss(X, Yoh_)

        # računanje gradijenata
        loss.backward()

        # korak optimizacije
        optimizer.step()

        # Postavljanje gradijenata na nulu
        optimizer.zero_grad()

        if i % 100 == 0 and ispis:
            print("U iteraciji " + str(i) + " gubitak je " + str(loss))


def eval(model, X):
    # ulaz je potrebno pretvoriti u torch.Tensor
    inputs = torch.tensor(X, requires_grad=True)
    # izlaze je potrebno pretvoriti u numpy.array

    # koristite torch.Tensor.detach() i torch.Tensor.numpy()
    outputs = model.forward(inputs).detach().cpu().numpy()

    return outputs


def testiraj_parametre(model, X, Yoh_):
    pred = eval(model, X).argmax(axis=1)
    precision = precision_score(Yoh_, pred, average='macro')
    recall = recall_score(Yoh_, pred, average='macro')
    accuracy = accuracy_score(Yoh_, pred)
    f1 = (2 * precision * recall) / (precision + recall)

    print("Točnost:" + str(accuracy) + "\n\nPreciznost:" + str(precision)
          + "\n\nOdziv:" + str(recall) + "\n\nf1:" + str(f1))
    print()
    return


def sig(x):
    return torch.sigmoid(x)

def relu(x):
	return torch.relu_(x)

if __name__ == "__main__":
    # inicijaliziraj generatore slučajnih brojeva
    np.random.seed(150)
    C=3
    # instanciraj podatke X i labele Yoh_
    X, Yoh_ = data.sample_gmm_2d(6, C, 10)

    # definiraj model:
    pt_deep = PTDeep([2, C], lambda x:sig(x))
    print(pt_deep.count_params())
    # nauči parametre (X i Yoh_ moraju biti tipa torch.Tensor):
    X_tensor = torch.tensor(X)
    Yoh_tensor = torch.tensor(data.convert_to_one_hot(Yoh_))

    train(pt_deep, X_tensor, Yoh_tensor, 10000, 0.1, 0.01, False)

    # dohvati vjerojatnosti na skupu za učenje
    probs = eval(pt_deep, X)
    # iscrtaj rezultate, decizijsku plohu
    plt.figure(figsize=(16, 9))
    rect = np.min(X, axis=0), np.max(X, axis=0)
    data.graph_surface(lambda x: np.argmax(eval(pt_deep, x), axis=1), rect, 0.5, 1024, 1024)
    data.graph_data(X, Yoh_, np.argmax(probs))

    plt.show()
