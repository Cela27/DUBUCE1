import pt_deep
import data
import numpy as np
import matplotlib.pyplot as plt
import torch
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import accuracy_score
import ksvm_wrap

def compare_pt_deep_and_ksvm():
    np.random.seed(100)
    C = 3
    # instanciraj podatke X i labele Yoh_
    X, Yoh_ = data.sample_gmm_2d(6, C, 10)

    # definiraj model:
    svm=ksvm_wrap.KSVMWrap(X, Yoh_, param_svm_c=1)
    pt_deep_model = pt_deep.PTDeep([2, C], lambda x: pt_deep.sig(x))

    # nauči parametre (X i Yoh_ moraju biti tipa torch.Tensor):
    X_tensor = torch.tensor(X)
    Yoh_tensor = torch.tensor(data.convert_to_one_hot(Yoh_))

    pt_deep.train(pt_deep_model, X_tensor, Yoh_tensor, 10000, 0.1,0.01, False)
    # dohvati vjerojatnosti na skupu za učenje
    pred = svm.predict(X)
    probs_ptd = pt_deep.eval(pt_deep_model, X)
    probs_ptd=np.argmax(probs_ptd, axis=1)

    precision_deep = precision_score(Yoh_, probs_ptd, average='macro')
    recall_deep = recall_score(Yoh_, probs_ptd, average='macro')
    accuracy_deep = accuracy_score(Yoh_, probs_ptd)
    f1_deep = (2 * precision_deep * recall_deep) / (precision_deep + recall_deep)
    print("Deep-Točnost:" + str(accuracy_deep) + " Preciznost:" + str(precision_deep)
          + " Odziv:" + str(recall_deep) + " f1:" + str(f1_deep))

    precision_svm = precision_score(Yoh_, pred, average='macro')
    recall_svm = recall_score(Yoh_, pred, average='macro')
    accuracy_svm = accuracy_score(Yoh_, pred)
    f1_svm = (2 * precision_svm * recall_svm) / (precision_svm + recall_svm)
    print("SVM-Točnost:" + str(accuracy_svm) + " Preciznost:" + str(precision_svm)
          + " Odziv:" + str(recall_svm) + " f1:" + str(f1_svm))


compare_pt_deep_and_ksvm()