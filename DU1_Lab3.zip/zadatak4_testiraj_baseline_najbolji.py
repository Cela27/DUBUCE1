import json
import os
import numpy as np
import torch

import zadatak1_load_data as load_data
import utils
from zadatak2_baseline import Baseline

TRAIN_PATH = "C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\DATA\\sst_train.csv"
VALIDATE_PATH = "C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\DATA\\sst_valid.csv"
TEST_PATH = "C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\DATA\\sst_test.csv"
EMBEDDINGS_PATH = "C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\DATA\\sst_glove.txt"
SAVE_FOLDER = "C:\\Users\\Antonio\\PycharmProjects\\DU1_Lab3\\ZAD4_REZULTATI\\BASELINE_BEST"

frekvencije = utils.frekvencije(TRAIN_PATH)
data_vocab = load_data.Vocab(frekvencije=frekvencije, max_size=5000, min_freq=1, additional=True)
label_vocab = load_data.Vocab(frekvencije={"positive": 2, "negative": 1}, max_size=5000, min_freq=1)

emb = utils.get_embedding_matrix(vocab=data_vocab, path=EMBEDDINGS_PATH)

train = load_data.NLPDataset(TRAIN_PATH, data_vocab, label_vocab)
valid = load_data.NLPDataset(VALIDATE_PATH, data_vocab, label_vocab)
test = load_data.NLPDataset(TEST_PATH, data_vocab, label_vocab)

save_folders = ['run1', 'run2', 'run3', 'run4', 'run5']

for i in range(5):
    save_folder = os.path.join(SAVE_FOLDER, save_folders[i])

    seed = np.random.randint(0, 2 ** 16)
    torch.manual_seed(seed)

    np.random.seed(seed)

    model = Baseline(embedding_matrix=emb, pool='avg', freeze=False)

    model.train(dataset=train, validation_dataset=valid, save_folder=save_folder, param_iter=5, param_delta=1e-3,
                batch_size=5, ispis=False)

    test_loss, test_precision, test_recall, test_acc, test_f1, test_cm = model.evaluate(test)
    test_results = dict()

    test_results['loss'] = test_loss
    test_results['acc'] = test_acc
    test_results['f1'] = test_f1
    test_results['cm'] = test_cm.tolist()
    test_path = os.path.join(save_folder, 'test_results.json')

    with open(test_path, mode="w+") as file:
        json.dump(test_results, file,
                  sort_keys=False, ensure_ascii=False, indent=2)
