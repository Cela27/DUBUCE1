import numpy as np
from sklearn import svm
import data
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt


class KSVMWrap:

    def __init__(self, X, Y_, param_svm_c=1, param_svm_gamma='auto'):
        # Konstruira omotač i uči RBF SVM klasifikator
        # X, Y_:      podatci i točni indeksi razreda
        # param_svm_c:     relativni značaj podatkovne cijene
        # param_svm_gamma: širina RBF jezgre
        self.svm = svm.SVC(C=param_svm_c, kernel='rbf', gamma=param_svm_c)
        self.svm.fit(X, Y_)

    def predict(self, X):
        # Predviđa i vraća indekse razreda podataka X
        return self.svm.predict(X)

    def get_scores(self, X):
        # Vraća klasifikacijske mjere
        # (engl. classification scores) podataka X;
        # ovo će vam trebati za računanje prosječne preciznosti.
        return self.svm.decision_function(X)

    def support(self):
        # Indeksi podataka koji su odabrani za potporne vektore
        return self.svm.support_


if __name__ == "__main__":
    # inicijaliziraj generatore slučajnih brojeva
    np.random.seed(100)

    C = 2

    # instanciraj podatke X i labele Yoh_
    X, Y_ = data.sample_gmm_2d(6, C, 10)

    svm = KSVMWrap(X, Y_, param_svm_c=1)
    pred = svm.predict(X)

    precision = precision_score(Y_, pred, average=None)
    recall = recall_score(Y_, pred, average=None)
    accuracy = accuracy_score(Y_, pred)
    f1 = (2 * precision * recall) / (precision + recall)
    print("Točnost:" + str(accuracy) + " Preciznost:" + str(precision)
          + " Odziv:" + str(recall) + " f1:" + str(f1))

    plt.figure(figsize=(16, 9))
    rect = np.min(X, axis=0), np.max(X, axis=0)
    data.graph_surface(lambda x: svm.predict(x), rect, 0.5, 1024, 1024)
    data.graph_data(X, Y_, pred, special=svm.support())
    plt.show()
