import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from pathlib import Path
import os
PATH = Path(__file__).parent / 'out_l2'

lambda_01=os.path.join(PATH, 'lambda0.1\\conv1_epoch_08_step_050000_input_000.png')
lambda_001=os.path.join(PATH, 'lambda0.01\\conv1_epoch_08_step_050000_input_000.png')
lambda_0001=os.path.join(PATH, 'lambda0.001\\conv1_epoch_08_step_050000_input_000.png')

plt.figure(figsize=(18,12))
plt.subplot(3, 1, 1)
img = mpimg.imread(lambda_01)
plt.imshow(img)
plt.title("Lambda=0.1")

plt.subplot(3, 1, 2)
img = mpimg.imread(lambda_001)
plt.imshow(img)
plt.title("Lambda=0.01")

plt.subplot(3, 1, 3)
img = mpimg.imread(lambda_0001)
plt.imshow(img)
plt.title("Lambda=0.001")
plt.show()