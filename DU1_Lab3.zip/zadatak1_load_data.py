from dataclasses import dataclass
from itertools import islice

import torch
import csv
import utils


@dataclass
class Instance:
    sentence: str
    label: str


class Vocab:

    def __init__(self, frekvencije, max_size, min_freq, additional=False):
        if max_size is None or max_size < 1:
            max_size = -1
        if min_freq is None or min_freq < 1:
            min_freq = 1

        self.max_size = max_size
        self.min_freq = min_freq

        for key, value in list(frekvencije.items()):
            if value < min_freq:
                del frekvencije[key]

        sortirano = dict(sorted(frekvencije.items(), key=lambda item: item[1], reverse=True))

        if max_size != -1:
            sortirano = dict(islice(sortirano.items(), max_size))

        self.itos = dict()
        self.stoi = dict()

        if additional:
            # dodaj dodatne znakove
            self.itos[0] = '<PAD>'
            self.itos[1] = '<UNK>'

            self.stoi['<PAD>'] = 0
            self.stoi['<UNK>'] = 1

        for i, (key, value) in enumerate(sortirano.items(), len(self.stoi)):
            self.stoi[key] = i
            self.itos[i] = key

    def itos(self):
        return self.itos

    def stoi(self):
        return self.stoi

    def max_size(self):
        return self.max_size

    def min_freq(self):
        return self.min_freq

    def encode(self, token, default_string='<UNK>'):
        if isinstance(token, list):
            return [self.encode(x) for x in token]

        return self.stoi.get(token, self.stoi.get(default_string))

    def decode(self, indexes, default_string='<UNK>'):

        if isinstance(indexes, list):
            return [self.decode(x) for x in indexes]

        return self.itos.get(indexes, default_string)


class NLPDataset(torch.utils.data.Dataset):
    def __init__(self, path, data_vocab, label_vocab):
        self.instances = []
        inst = utils.get_instances(path)

        for instance in inst:
            self.instances.append([utils.tokenize(instance.sentence), instance.label.strip()])

        self.data_vocab = data_vocab
        self.label_vocab = label_vocab

    def vocabs(self):
        return self.data_vocab, self.label_vocab

    def instances(self):
        return list(self.instances)

    def data_vocab(self):
        return self.data_vocab

    def label_vocab(self):
        return self.label_vocab

    def __len__(self):
        return len(self.instances)

    def __getitem__(self, index):
        vocabs = self.vocabs()
        return [torch.tensor(vocab.encode(element)) for vocab, element in zip(vocabs, self.instances[index])]
