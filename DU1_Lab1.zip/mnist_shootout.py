import sys
import torch
import torchvision
from sklearn import svm
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import accuracy_score
import pt_deep
import numpy as np
import matplotlib.pyplot as plt
import warnings
from sklearn.model_selection import train_test_split

warnings.filterwarnings("ignore")


def convert_to_one_hot_minst(data):
    converted = list()

    for tensor in data:
        primjer = np.zeros(10)
        primjer[tensor.data] = 1.

        converted.append(primjer)
    converted = np.asarray(converted)
    return torch.tensor(converted)


def zadatak1(X_train, X_test, Y_train, Y_test,param_niter, param_delta):
    # koristiu relu
    pt_deep_model = pt_deep.PTDeep([784, 10], lambda x: pt_deep.relu(x))

    lambdas = [0.001, 0.01, 0.1, 1]
    br = 1
    plt.figure(figsize=(20, 12))
    for param_lambda in lambdas:

        pt_deep.train(pt_deep_model, X_train, Y_train, param_niter, param_delta, param_lambda, True)
        # probs_ptd = pt_deep.eval(pt_deep_model, X_test)

        weights = pt_deep_model.weights

        brojevi = weights[0].detach().cpu().numpy().T.reshape((-1, 28, 28))
        cmap = plt.get_cmap('gray')

        for i in range(0, len(brojevi)):
            plt.subplot(8, 5, br)
            plt.title("Broj: " + str(i) + " za lambda=" + str(param_lambda))
            plt.imshow(brojevi[i], cmap=cmap)
            br += 1
    plt.show()
    return


def zadatak2(X_train, X_test, Y_train, Y_test, param_niter, param_delta):
    #configurations=[[784, 10], [784, 100, 10], [784, 100, 100,10], [784, 100, 100, 100, 10]]
    configurations=[[784, 10], [784, 100, 10]]
    losses = {}

    for i in range(0, len(configurations)):
        print("Konfiguracija je " + str(configurations[i]))
        pt_deep_model = pt_deep.PTDeep(configurations[i], lambda x: pt_deep.relu(x))
        optimizer = torch.optim.SGD(params=pt_deep_model.parameters(), lr=param_delta)
        conf_losses = []

        for j in range(1, param_niter + 1):
            loss = pt_deep_model.get_loss(X_train, Y_train)
            conf_losses.append(float(loss.detach().cpu().numpy()))
            # računanje gradijenata
            loss.backward()
            # korak optimizacije
            optimizer.step()

            # Postavljanje gradijenata na nulu
            optimizer.zero_grad()
            # if j % 100 ==0:
            # print("U iteraciji " + str(j) + " gubitak je " + str(loss))

        losses[i] = conf_losses
        pt_deep.testiraj_parametre(pt_deep_model, X_test, Y_test)

    plt.figure(figsize=(16, 8))
    for key in losses:
        plt.plot(range(1, param_niter + 1), losses[key], label=configurations[key])
    plt.legend()
    plt.show()

    return


def zadatak3(X_train, X_test, Y_train, Y_test, param_niter, param_delta):
    lambdas=[0.0001, 0.001,0.01,0.1,1]
    losses = {}

    for i in range(0, len(lambdas)):
        pt_deep_model = pt_deep.PTDeep([784,100, 10], lambda x: pt_deep.relu(x))
        optimizer = torch.optim.SGD(params=pt_deep_model.parameters(), lr=param_delta, weight_decay=lambdas[i])
        lambda_losses = []

        for j in range(1, param_niter + 1):
            loss = pt_deep_model.get_loss(X_train, Y_train)
            lambda_losses.append(float(loss.detach().cpu().numpy()))
            # računanje gradijenata
            loss.backward()
            # korak optimizacije
            optimizer.step()

            # Postavljanje gradijenata na nulu
            optimizer.zero_grad()
            if j % 100 ==0:
                print("U iteraciji " + str(j) + " gubitak je " + str(loss))

        losses[i] = lambda_losses

    plt.figure(figsize=(16, 8))
    for key in losses:
        plt.plot(range(1, param_niter + 1), losses[key], label="Lambda="+str(lambdas[key]))
    plt.legend()
    plt.show()

    return


def zadatak4(X_train, X_test, Y_train, Y_test, br_iteracija, param_niter, param_delta):
    X_train, X_validate, Y_train, Y_validate = train_test_split(X_train, Y_train, test_size = 0.2, random_state = 100)
    pt_deep_model = pt_deep.PTDeep([784,100, 10], lambda x: pt_deep.relu(x))
    optimizer = torch.optim.SGD(params=pt_deep_model.parameters(), lr=param_delta)
    min_loss=sys.maxsize

    best_weights = pt_deep_model.weights
    best_biases = pt_deep_model.biases
    best_iter=0
    br_iteracija_bez_napredka=0

    for i in range(1, param_niter + 1):
        loss = pt_deep_model.get_loss(X_train, Y_train)
        # računanje gradijenata
        loss.backward()
        # korak optimizacije
        optimizer.step()
        # Postavljanje gradijenata na nulu
        optimizer.zero_grad()

        val_loss=pt_deep_model.get_loss(X_validate, Y_validate)

        if min_loss > val_loss:
            min_loss = val_loss

            best_weights = pt_deep_model.weights
            best_biases = pt_deep_model.biases

            best_iter=i
            br_iteracija_bez_napredka = 0
        else:
            br_iteracija_bez_napredka += 1

            if br_iteracija_bez_napredka >= br_iteracija:
                pt_deep_model.weights = best_weights
                pt_deep_model.biases = best_biases
                break

        if i % 100 ==0:
            print("U iteraciji " + str(i) + " gubitak je " + str(loss))

    print("Najbolja je iteracija "+str(best_iter)+" sa gubitkom "+str(min_loss)+" na validate skupu")
    pt_deep.testiraj_parametre(pt_deep_model, X_test, Y_test)
    return


def zadatak5(X_train, X_test, Y_train, Y_test, param_niter, param_delta):
    batches = [64, 128, 256]
    losses = {}

    for i in range(0, len(batches)):
        pt_deep_model = pt_deep.PTDeep([784, 100, 10], lambda x: pt_deep.relu(x))
        optimizer = torch.optim.SGD(params=pt_deep_model.parameters(), lr=param_delta)
        batches_losses = []

        for j in range(1, param_niter + 1):
            X_batches = torch.split(X_train, batches[i])
            Y_batches = torch.split(Y_train, batches[i])
            batch_losses=[]
            for X, Y in zip(X_batches, Y_batches):
                loss = pt_deep_model.get_loss(X, Y)
                batch_losses.append(float(loss.detach().cpu().numpy()))
                # računanje gradijenata
                loss.backward()
                # korak optimizacije
                optimizer.step()

                # Postavljanje gradijenata na nulu
                optimizer.zero_grad()
            if j % 10 ==0:
                print("U iteraciji " + str(j) + " gubitak je " + str(loss))
            batches_losses.append(np.mean(batch_losses))
        losses[i] = batches_losses

    plt.figure(figsize=(16, 8))
    for key in losses:
        plt.plot(range(1, param_niter + 1), losses[key], label="Batch size=" + str(batches[key]))
    plt.legend()
    plt.show()

    return


def zadatak6(X_train, X_test, Y_train, Y_test, param_niter, param_delta):
    pt_deep_model = pt_deep.PTDeep([784, 100, 10], lambda x: pt_deep.relu(x))
    optimizer = torch.optim.Adam(params=pt_deep_model.parameters(), lr=param_delta)
    losses = []

    for j in range(1, param_niter + 1):
        loss = pt_deep_model.get_loss(X_train, Y_train)
        losses.append(float(loss.detach().cpu().numpy()))
        # računanje gradijenata
        loss.backward()
        # korak optimizacije
        optimizer.step()

        # Postavljanje gradijenata na nulu
        optimizer.zero_grad()
        if j % 100 ==0:
            print("U iteraciji " + str(j) + " gubitak je " + str(loss))

    print("S adamom ovo su rezultati:")
    pt_deep.testiraj_parametre(pt_deep_model, X_test, Y_test)

    plt.figure(figsize=(16, 8))
    plt.plot(range(1, param_niter + 1), losses)
    plt.show()

    return


def zadatak7(X_train, X_test, Y_train, Y_test, param_niter, param_delta):
    pt_deep_model = pt_deep.PTDeep([784, 100, 10], lambda x: pt_deep.relu(x))
    optimizer = torch.optim.Adam(params=pt_deep_model.parameters(), lr=param_delta)
    losses = []
    lr_scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer, gamma=1-1e-4)

    for j in range(1, param_niter + 1):
        loss = pt_deep_model.get_loss(X_train, Y_train)
        losses.append(float(loss.detach().cpu().numpy()))
        # računanje gradijenata
        loss.backward()
        # korak optimizacije
        optimizer.step()
        lr_scheduler.step()

        # Postavljanje gradijenata na nulu
        optimizer.zero_grad()
        if j % 100 ==0:
            print("U iteraciji " + str(j) + " gubitak je " + str(loss))

    print("S Adamom i schedulerom ovo su rezultati:")
    pt_deep.testiraj_parametre(pt_deep_model, X_test, Y_test)

    plt.figure(figsize=(16, 8))
    plt.plot(range(1, param_niter + 1), losses)
    plt.show()

    return


def zadatak8(X_train, X_test, Y_train, Y_test):
    pt_deep_model = pt_deep.PTDeep([784, 100, 10], lambda x: pt_deep.relu(x))
    print("Rezultati random generiranih tezina su: ")
    pt_deep.testiraj_parametre(pt_deep_model, X_test, Y_test)
    return


def zadatak9(X_train, X_test, Y_train, Y_test):

    linear_svm=svm.SVC(kernel="linear", decision_function_shape="ovo")
    linear_svm.fit(X_train, Y_train)
    pred = linear_svm.predict(X_test)

    precision = precision_score(Y_test, pred, average='macro')
    recall = recall_score(Y_test, pred, average='macro')
    accuracy = accuracy_score(Y_test, pred)
    f1 = (2 * precision * recall) / (precision + recall)
    print("Za linear:")
    print("Točnost:" + str(accuracy) + "\n\nPreciznost:" + str(precision)
          + "\n\nOdziv:" + str(recall) + "\n\nf1:" + str(f1))
    print()

    rbf_svm = svm.SVC(kernel="rbf", decision_function_shape="ovo")
    rbf_svm.fit(X_train[:100], Y_train[:100])

    pred = rbf_svm.predict(X_test)

    precision = precision_score(Y_test, pred, average='macro')
    recall = recall_score(Y_test, pred, average='macro')
    accuracy = accuracy_score(Y_test, pred)
    f1 = (2 * precision * recall) / (precision + recall)
    print("Za rbf:")
    print("Točnost:" + str(accuracy) + "\n\nPreciznost:" + str(precision)
          + "\n\nOdziv:" + str(recall) + "\n\nf1:" + str(f1))
    print()
    return


dataset_root = '/tmp/mnist'  # change this to your preference
mnist_train = torchvision.datasets.MNIST(dataset_root, train=True, download=True)
mnist_test = torchvision.datasets.MNIST(dataset_root, train=False, download=True)

x_train, y_train = mnist_train.data, mnist_train.targets
x_test, y_test = mnist_test.data, mnist_test.targets
x_train, x_test = x_train.float().div_(255.0), x_test.float().div_(255.0)

N = x_train.shape[0]
D = x_train.shape[1] * x_train.shape[2]
C = y_train.max().add_(1).item()

y_train_svm=y_train
y_train = convert_to_one_hot_minst(y_train)
# y_test=convert_to_one_hot_minst(y_test)
x_train = x_train.view(-1, 784)
x_test = x_test.view(-1, 784)

#zadatak1(x_train, x_test, y_train, y_test,1000, 0.1)
#zadatak2(x_train, x_test, y_train, y_test,1000, 0.05)
#zadatak3(x_train, x_test, y_train, y_test, 1000, 0.1)
#zadatak4(x_train, x_test, y_train, y_test, 10, 200, 0.1)
#zadatak5(x_train, x_test, y_train, y_test, 100, 0.1)
#zadatak6(x_train, x_test, y_train, y_test, 1000, 0.1)
#zadatak7(x_train, x_test, y_train, y_test, 1000, 0.1)
#zadatak8(x_train, x_test, y_train, y_test)
zadatak9(x_train[:1000], x_test, y_train_svm[:1000], y_test)
